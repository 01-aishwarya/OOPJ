
//1. Write a Java program that throws an arithmetic exception and 
//catch it using a try-catch block.

package in.cdac.kh;

public class Arith {
	public static void main(String[] args)
	{
		try {
	int a=8;
	int b=0;
	
	int  c=a/b;
		
	System.out.println(c);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
