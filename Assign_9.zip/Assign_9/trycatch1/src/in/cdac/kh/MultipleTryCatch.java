
/*
 * 4. Write a code for arithmetic exception using one try block & multiple 
 * 
 * catch block & check which catch block handle that exception.
 */
package in.cdac.kh;

public class MultipleTryCatch {
	public static void main(String[] args)
	{
		try {
	int a=8;
	int b=0;
	
	int  c=a/b;
		
	System.out.println(c);
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		catch(Throwable e)
		{
			e.printStackTrace();
		}
	}
}
