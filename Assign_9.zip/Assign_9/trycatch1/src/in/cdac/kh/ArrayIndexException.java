
// 3. Write a Java program throws an array index out of bound exception.

package in.cdac.kh;

public class ArrayIndexException {
	
	public static void main(String[] args)
	{
		int[] arr=new int[3];
		
		for(int i=0;i<=arr.length;i++)
			System.out.println(arr[i]);
	}

}
