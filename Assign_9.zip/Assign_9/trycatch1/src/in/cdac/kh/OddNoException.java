
/*
 * 2. Write a Java program to create a method that takes an integer as a
 *  parameter and throws an exception if the number is odd.

 */
package in.cdac.kh;

public class OddNoException {
	
	public static void main(String args[])
	{
		try {
		OddNoException.oddNo(5);
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
	}

	private static void oddNo(int i) throws Exception {
		// TODO Auto-generated method stub
		if(i%2!=0)
		{
			throw new Exception("no is odd");
		}
	}

}
