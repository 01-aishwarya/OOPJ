package in.cdac.kh;

import java.util.Scanner;

public class EqualityOfTwoArray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 5 elements :");
		
		int arr1[]=new int[5];
		for(int i=0;i<arr1.length;i++)
			arr1[i]=sc.nextInt();
		
		System.out.println("---------------");
	System.out.println("enter 5 elements :");
		
		int arr2[]=new int[5];
		for(int i=0;i<arr2.length;i++)
			arr2[i]=sc.nextInt();
		System.out.println("=====================");
		int flag=0;
		for(int i=0;i<arr1.length;i++)
		{
			if(arr1[i]!=arr2[i])
			{
				flag++;
			}
			if(flag >0)
			{
				System.out.println("Arrays elemnts r NOT SAME.");
				break;
			}
		}
		if(flag==0)
		System.out.println("Arrays elemnts are SAME.");
	}
}
