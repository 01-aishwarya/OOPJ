
 // Print the third-largest number in an array without sorting it 
// Input: [ 24,54,31,16,82,45,67]

package in.cdac.kh;

public class ThirdLargestNumber {
	public static void main(String[] args)
	{
		int[] arr= {24,54,31,16,82,45,67};
		int max=0;
		int secMax=0;
		int thrdMax=0;
		
		for(int i=0;i<arr.length;i++)
		{
			
			if(max <arr[i])
			{
				thrdMax=secMax;
				secMax=max;
				max=arr[i];
				//System.out.println(max);
			}
			 if(secMax <arr[i] && secMax!=max && arr[i] <max  )
			{
				 thrdMax=secMax;
				secMax=arr[i];
				//System.out.println("--"+secMax);
			}
		 if(thrdMax <arr[i] && thrdMax!=max && thrdMax!=secMax && arr[i] <secMax)
			{
			thrdMax=arr[i];	
			//System.out.println("---"+thrdMax);
			}
		}
		
		
		System.out.println("\n---------------");
		System.out.println("Third-Largest : "+thrdMax);
		
		
	}

}
