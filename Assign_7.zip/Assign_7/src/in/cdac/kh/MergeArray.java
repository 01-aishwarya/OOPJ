// Write a program to merge two arrays of integers by reading one number at a time from each array
 // until  one of the array is exhausted, and then concatenating the remaining numbers.
// Input: [23,60,94,3,102] and [42,16,74]


package in.cdac.kh;

public class MergeArray {
	public static void main(String[] args)
	{
		int[] a= {23,60,94,3,102};
		int[] b= {42,16,74};
		int[] c=new int[a.length+b.length];
		int j=0,k=0,i=0,h=0;
		for(i=0;i<c.length;i++)
		{
			if(a.length>b.length)
			{
				if(j<=k )
				{
					if(a.length!=j)
					{
				c[i]=a[j];
				j++;
				//System.out.print("j"+j);
					}
					else
					{
						
						break;
					}
				}
				else
				{
					if(b.length!=k)
					{
					c[i]=b[k];
					k++;
					//System.out.print("k"+k);
					}
					else
					{
						break;}
				}
			
			}
			
		}
		
		while(a.length!=j)
				{
			c[i]=a[j];
			i++;
			j++;
			
		}
		
		while(b.length!=k)
		{
	c[i]=a[k];
	i++;
	k++;
	
}
		
		
		System.out.print("A : ");
		
		
		for(int i1=0;i1<a.length;i1++)
		{
			System.out.print(a[i1]+" ");
		}
		System.out.print("\nB : ");
	
		for(int i1=0;i1<b.length;i1++)
		{
			System.out.print(b[i1]+" ");
		}
		System.out.println("\n----------------------");
		System.out.print("\nAlternate Merged Array : ");
		for(int i1=0;i1<c.length;i1++)
		{
			System.out.print(c[i1]+" ");
		}
	}

}
