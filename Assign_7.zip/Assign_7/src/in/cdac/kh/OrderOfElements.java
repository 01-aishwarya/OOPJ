/*
 * Given an array of integers, print whether the numbers are in ascending order or in descending order or in random order without sorting
 Input: [5,14,35,90,139] Output: Ascending 
 Input: [88,67,35,14,-12] Output: Descending
Input: [65,14,129,34,7] Output: Random 

 */

package in.cdac.kh;

import java.util.Scanner;

public class OrderOfElements {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length of arr :");
		int l=sc.nextInt();
		System.out.println("enter elemnts of array : ");
		int[] arr=new int[l];
		int j=0;
		while(l!=0)
		{
			arr[j++]=sc.nextInt();
			l--;
			System.out.println("enter next element : ");
		}
		int flag=0,m=0;
		for(int i=0;i<arr.length-1;i++)
		{
			if(arr[i]<arr[i+1])
			{
				flag++;
			}
			else
			{
				m++;
			}
		}
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.print("\n-------------\n");
		
		if(flag+1==arr.length)
		{
			System.out.println("Ascending Order");
		}
		else if(m+1==arr.length)
		{
			System.out.println("Descending Order");
		}
		else
		{
			System.out.println("Random Order");
		}
	}

}
