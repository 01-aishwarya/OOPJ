package in.cdac.kh;
// 1. Write a program to print elements of Array ? 


public class PrintArrayElement {
	public static void main(String[] args)
	{
		int[] arr= {4,5,6,7,2,3,9};
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
}
