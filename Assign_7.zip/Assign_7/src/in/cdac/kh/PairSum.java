package in.cdac.kh;

import java.util.Scanner;
// Write a Java program to find all pairs of elements in an integer array 
// whose sum is equal to a given number?

public class PairSum {
	
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter a elements :");
	int a=sc.nextInt();
	
	System.out.println("enter length of array :");
	int b=sc.nextInt();
	int arr1[]=new int[b];

	int k=0;
	while(b!=0)
	{
	System.out.println("enter element of array:");

		arr1[k]=sc.nextInt();
		k++;
	b--;
	}
	
	System.out.println("---------------");
	
	
	for(int i=0;i<arr1.length-1;i++) // 4 // 5 //  1 2 6 2 8 
	{
		for(int j=0;j<arr1.length-1;j++) //
		{
			if((arr1[i]+arr1[j+1])==a)
			{
				System.out.print(" ( "+arr1[i]+" , " + arr1[j+1]+" ) ");
			}
		}
		System.out.println();
	}
	
	System.out.println("---------------");

}
}
