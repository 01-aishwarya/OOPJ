package in.cdac.kh;

import java.util.Scanner;

public class MaxMinNumber {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter length of array :");
	int b=sc.nextInt();
	int arr1[]=new int[b];

	int k=0;
	while(b!=0)
	{
	System.out.println("enter element of array:");

		arr1[k]=sc.nextInt();
		k++;
	b--;
	}
	System.out.println("======================\n Original Elements :\n");
	int min=arr1[0],max=arr1[0];
	
	for(int i=1;i<arr1.length;i++)
	{
		if(min>arr1[i])
		{
			min=arr1[i];
		}
		if(max<arr1[i])
		{
			max=arr1[i];
		}
	}
	
	System.out.println("Min : "+min);
	System.out.println("Max : "+max);
}
}
