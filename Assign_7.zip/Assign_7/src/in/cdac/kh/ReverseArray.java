package in.cdac.kh;

import java.util.Scanner;

// Write a program to reverse an Array in java . 
public class ReverseArray {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter length of array :");
		int b=sc.nextInt();
		int arr1[]=new int[b];

		int k=0;
		while(b!=0)
		{
		System.out.println("enter element of array:");

			arr1[k]=sc.nextInt();
			k++;
		b--;
		}
		System.out.println("======================\n Original Elements :\n");
		
		for(int i=0;i<arr1.length;i++)
		{
			System.out.print(arr1[i]+" ");
		}
		System.out.println("\n---------------------\n Reversed Elements :\n");
		for(int i=arr1.length-1;i>=0;i--)
		{
			System.out.print(arr1[i]+" ");
		}
	}
}
