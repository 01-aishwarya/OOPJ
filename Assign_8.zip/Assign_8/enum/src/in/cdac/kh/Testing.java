package in.cdac.kh;

public class Testing {
	public static void main(String[] args)
	{
		DayOfWeek day=DayOfWeek.SUNDAY;
		DayOfWeek[] no=DayOfWeek.values();
		
		System.out.println(day.print(day));
		System.out.println("=========");
		System.out.println(day.getDayNumber(day));
		System.out.println("=========");
		System.out.println(day.getNextDay(day));
		System.out.println("=========");
		for(int i=0;i<no.length;i++)
		System.out.println(no[i]);
		
		
	}
}
