package in.cdac.kh;

public enum DayOfWeek {
	
	SUNDAY(1,"sunday"),MONDAY(2,"monday"),TUESDAY(3,"tuesday"),WEDNESDAY(4,"wednesday"),
	THURSDAY(5,"thursday"),FRIDAY(6,"friday"),SATURDAY(7,"saturday");
	
	private int no;
	private String val;
	DayOfWeek(int no,String val)
	{
		this.no=no;
		this.val=val;
	}
	public String print(DayOfWeek day)
	{
		return day.val;
	}
	
	public String getNextDay(DayOfWeek day)
	{
		int n=no;
	//	System.out.println(n);
		DayOfWeek[] d= day.values();
		DayOfWeek g=d[n];
		return g.val;
	}
	
	
	public int getDayNumber(DayOfWeek day)
	{
		return day.no;
	}
	
	public DayOfWeek[] getWeekendDays()
	{
		return DayOfWeek.values();
	}
	
}
