package in.cdac.kh;

import java.util.Scanner;

public class Matrix {
	public static int[][] arr;
	public static int[][] brr;
	public static Scanner sc;
	static int a;
	static int b;
	public static int[][] crr;
	public static void main(String[] args)
	{
	sc=new Scanner(System.in);
		System.out.println("Enter a row and column");
		a=sc.nextInt();
		b=sc.nextInt();
		 arr=new int[a][b];
		crr=new int[a][b];
		
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.println("enter a elemnt :");
				arr[i][j]=sc.nextInt();
			}
		}
	//	System.out.println("enter a elemnt  fro 2nd matrix:");
		
	//	System.out.println("Enter a row and column");
	 brr=new int[a][b];
		
		
		
		for(int i=0;i<brr.length;i++)
		{
			for(int j=0;j<brr[i].length;j++)
			{
				System.out.println("enter a elemnt :");
				brr[i][j]=sc.nextInt();
			}
		}
		
		
		
		int choice=1;
		
		while(choice!=0)
		{
			System.out.println("1. Addition of two matrices ");
			System.out.println("2. Subtraction of two matrices");
			System.out.println("3. Multiplication of two matrices ");
			System.out.println("4. Transpose of a matrix  ");
			System.out.println("=========");
			
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				Matrix.addition();
			
				break;
			case 2:
				Matrix.substraction();
			
				break;
			case 3:
				Matrix.multiplication();
			
				break;
			case 4:
				Matrix.transpose();
				break;
		
				
			}
			
		}
	}

	private static void display(int[][] crr2) {
		// TODO Auto-generated method stub 
		// 3 4
		// 1 4 
		
		for(int i=0;i<a;i++)
		{
			for(int j=0;j<b;j++)
			{
			System.out.print(crr2[i][j]+" 	");
			}
			System.out.println();
		}
		System.out.println("=========");
	}

	private static void transpose() {
		// 00  01 = 00 10
		// 10  11 = 01 11
		int c=0;
		for(int i=0;i<a;i++)
		{
			c=i;//1
			for(int j=0;j<b;j++)
			{
			System.out.print(crr[j][c]+" 	");
			
			}
			System.out.println();
		}
		System.out.println("=========");
	}

	private static void multiplication() {
		for(int i=0;i<a;i++)
		{
			for(int j=0;j<b;j++)
			{
				crr[i][j]=arr[i][j]*brr[i][j];
			}
		}
		display(crr);
	}

	private static void substraction() {
		for(int i=0;i<a;i++)
		{
			for(int j=0;j<b;j++)
			{
				crr[i][j]=arr[i][j]-brr[i][j];
			}
		}
		display(crr);
	}

	private static void addition() {
		// 3 x 3  3 x 3
	
		
		for(int i=0;i<a;i++)
		{
			for(int j=0;j<b;j++)
			{
				crr[i][j]=arr[i][j]+brr[i][j];
			}
		}
		
		display(crr);
	}


}
