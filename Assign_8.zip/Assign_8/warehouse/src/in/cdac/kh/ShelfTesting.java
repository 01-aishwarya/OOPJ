package in.cdac.kh;

import java.util.Scanner;

public class ShelfTesting {

	public static Scanner sc=new Scanner(System.in);
	public static Shelf[] shelf;
	public static void main(String[] args)
	{
		shelf=new Shelf[10];
	
		
		int choice=1;
		
		while(choice!=0)
		{
			System.out.println("1. Add Item to Shelf : ");
			System.out.println("2. Remove Item From Shelf : ");
			System.out.println("3. Display Shelf Content : ");
			System.out.println("0. To EXIT : ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				ShelfTesting.addItem();
				break;
			case 2:
				ShelfTesting.removeItem();
			    break;
			case 3:
				ShelfTesting.displayItem();
				break;
			case 0:
				System.out.println("You're Exited...");
				System.out.println("=========================");
			}
		}
	
	}
	
	
	
	
	private static void displayItem() {
		// TODO Auto-generated method stub
		for(int i=0;i<shelf.length;i++)
		{
			if(shelf[i]!=null)
				if(shelf[i].getItem()!=null)
			System.out.println("Content : 		"+shelf[i].getItem());
		}
		System.out.println("=============================");
	}
	
	
	
	private static void removeItem() {
		// TODO Auto-generated method stub
		System.out.print("enter item name to remove 	:	");
		String str=sc.next();
		for(int i=0;i<shelf.length;i++)
		{
			if(shelf[i]!=null && shelf[i].getItem().equals(str))
			{
				
				shelf[i].setItem(null);
			}
		}
	
	}
	
	
	
	
	private static void addItem() {
		// TODO Auto-generated method stub
		for(int i=0;i<shelf.length;i++)
		{
			if(shelf[i]==null)
			{
				System.out.print("enter item to shelf : ");
				String str=sc.next();
				shelf[i]=new Shelf(str);
				break;
			}
		}
	}
}
