package in.cdac.kh;

public class Shelf {
	private String item;

	public Shelf(String item) {
		super();
		this.item = item;
	}

	public Shelf() {
		super();
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	
}
