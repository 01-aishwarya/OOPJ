package in.cdac.kh;

public class Flight {
	private String flight;
	private int seatAva;
	public Flight(String flight, int seatAva) {
		super();
		this.flight = flight;
		this.seatAva = seatAva;
	}
	public Flight() {
		super();
	}
	public String getFlight() {
		return flight;
	}
	public void setFlight(String flight) {
		this.flight = flight;
	}
	public int getSeatAva() {
		return seatAva;
	}
	public void setSeatAva(int seatAva) {
		this.seatAva = seatAva;
	}

	
}
