package in.cdac.kh;

import java.util.Scanner;

public class FlightTesting {
	public static Scanner sc=new Scanner(System.in);
	public static User[] user;
	public static Flight[] flight;
	
	public static void main(String[] args)
	{
		user=new User[10];
		flight=new Flight[5];
		
//		FlightTesting.userRegisteration();
//		FlightTesting.displayUser();
//		FlightTesting.addFlight();
//		FlightTesting.displayFlight();
//		FlightTesting.viewReservation();
//		FlightTesting.seatReservation();
//	FlightTesting.cancelReservation();
		
	
	int choice=1;
	while(choice!=0)
	{
	System.out.println("1. user regist");
	System.out.println("2. dispaly user");
	System.out.println("3. add flight");
	System.out.println("4. dispaly flight");
	System.out.println("5. seat regis");
	System.out.println("6. view regis");
	System.out.println("7. cancel regsit");
	System.out.println("0. EXIT");
	System.out.println("===========================");
	
			
	
	System.out.println("enter a choice :");
	choice=sc.nextInt();
	
	
		
		switch(choice)
		{
		case 1:
			FlightTesting.userRegisteration();
			break;
		case 2:
			FlightTesting.displayUser();
			break;
		case 3:
			FlightTesting.addFlight();
			break;
		case 4:
			FlightTesting.displayFlight();
			break;
		case 5:
			FlightTesting.seatReservation();
		
			break;
		case 6:
			FlightTesting.viewReservation();
			break;
		case 7:
			FlightTesting.cancelReservation();
			break;
			
		}
	}
	//	FlightTesting.viewReservation();
		
	}
	
	
	private static void cancelReservation() {
		// TODO Auto-generated method stub
		for(int i=0;i<flight.length;i++)
		{
			if(flight[i]!=null)
			{
				
				System.out.println("enter user email:");
				String email=sc.next();
				
				for(int j=0;j<user.length;j++)
				{
					if(user[i].getEmail().equals(email))
					{
						user[i].setFlight(" ");
						user[i].setSeat(0);
						break;
					}
				}
				flight[i].setSeatAva(i);
				break;
			
			}
	}
	}
	
	
	
	private static void viewReservation() {
		
		for(int i=0;i<user.length;i++)
		{
			if(user[i]!=null )
			{
				//System.out.println(user[i].getFlight()+"-----");
				if(!user[i].getFlight().isEmpty())
				{
					System.out.println("user name:	"+user[i].getName() );
					System.out.println("user email:	"+user[i].getEmail() );
					System.out.println("user contact NO:	"+user[i].getContactNo());
					System.out.println("user flight:	"+user[i].getFlight());
					System.out.println("user seat no:	"+user[i].getSeat());
					System.out.println("=================");
				}
				
			}
			
		}
		// TODO Auto-generated method stub
		
	}
	private static void seatReservation() {
		// TODO Auto-generated method stub
		for(int i=0;i<flight.length;i++)
		{
			if(flight[i]!=null)
			{
				
				System.out.println("enter user email:");
				String email=sc.next();
				
				for(int j=0;j<user.length;j++)
				{
					if(user[i].getEmail().equals(email))
					{
						user[i].setFlight(flight[i].getFlight());
						user[i].setSeat(flight[i].getSeatAva());
						break;
					}
				}
				break;
			
			}
			
		}
		
	}
	private static void displayFlight() {
		// TODO Auto-generated method stub
		for(int i=0;i<flight.length;i++)
		{
			if(flight[i]!=null)
			{
				
				System.out.println("flight name:	"+flight[i].getFlight() );
				System.out.println("seat avil:	"+flight[i].getSeatAva() );
				System.out.println("=================");
			}
			
		}
	}
	private static void addFlight() {
		// TODO Auto-generated method stub
		for(int i=0;i<flight.length;i++)
		{
			if(flight[i]==null)
			{
				System.out.println("enter flight name: " );
				String name=sc.next();
				System.out.println("enter seat no: " );
				int no=sc.nextInt();
				flight[i]=new Flight(name,no);
				break;
			}
			
		}
		
	}
	private static void displayUser() {
		// TODO Auto-generated method stub
		for(int i=0;i<user.length;i++)
		{
			if(user[i]!=null)
			{
				
				System.out.println("user name:	"+user[i].getName() );
				System.out.println("user email:	"+user[i].getEmail() );
				System.out.println("user contact NO:	"+user[i].getContactNo());
				System.out.println("=================");
			}
			
		}
		
	}
	private static void userRegisteration() {
		// TODO Auto-generated method stub
		for(int i=0;i<user.length;i++)
		{
			if(user[i]==null)
			{
				System.out.println("enter your name: " );
				String name=sc.next();
				System.out.println("enter your email: " );
				String email=sc.next();
				System.out.println("enter your contact no: " );
				long no=sc.nextLong();
				user[i]=new User(name,email,no," ",0);
				break;
			}
			
		}
		
	}

}
