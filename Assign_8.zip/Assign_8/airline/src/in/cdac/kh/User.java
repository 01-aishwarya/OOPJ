package in.cdac.kh;

public class User {
	
	private String name;
	private String email;
	private long contactNo;
	private String flight;
	private int seat;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getFlight() {
		return flight;
	}
	public void setFlight(String flight) {
		this.flight = flight;
	}
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat = seat;
	}
	public User(String name, String email, long contactNo, String flight, int seat) {
		super();
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.flight = flight;
		this.seat = seat;
	}
	public User() {
		super();
	}
	
	
	
	

}
