package in.cdac.kh;

import java.util.Scanner;

public class BookTicketTesting {
	public static Scanner sc=new Scanner(System.in);
	public static Seat seat[][];
	public static void main(String[] args)
	{
		seat=new Seat[][]
				{
			{new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0)},
			{new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0)},
			{new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0)},
			{new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0),new Seat(0,0,0,0,0)},
				};
		
	
		
		int choice=1;
		
		while(choice!=0)
		{
			System.out.println("1. To Display sold and availiable seats : ");
			System.out.println("2. To Purchase seats : ");
			System.out.println("3. To View Purchased Report : ");
			System.out.println("4. To VIew Availble Seat Report : ");
			System.out.println("0. To EXIT : ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				BookTicketTesting.displaySeatingChart();
				break;
			case 2:
				BookTicketTesting.purchaseSeat();
			    break;
			case 3:
				BookTicketTesting.viewReport();
				break;
			case 4:
				BookTicketTesting.availableReport();
				break;
			case 0:
				System.out.println("You're Exited...");
				System.out.println("=========================");
			}
		}
		
	}
	private static void availableReport() {
		// TODO Auto-generated method stub
	
		int ava=0;
		for(int i=0;i<seat.length;i++)
		{
			for(int j=0;j<seat[i].length;j++)
			{
				if(seat[i][j].getAvailbleSeat()==0)
				{
				ava++;
				
				}
			}
		
		}
		System.out.println("seat available: "+ava);

		System.out.println("=======================");
	}
	private static void viewReport() {
		// TODO Auto-generated method stub
		
		double rev=0.0;
		int sold=0;
		for(int i=0;i<seat.length;i++)
		{
			for(int j=0;j<seat[i].length;j++)
			{
				if(seat[i][j].getAvailbleSeat()==1)
				{
				rev=rev+seat[i][j].getPrice();
					sold++;
				
				}
			}
		
		}
		System.out.println("ticket sold : "+sold);
		System.out.println("total revenue : "+rev);
		System.out.println("=======================");
		
		
	}
	private static void purchaseSeat() {
		// TODO Auto-generated method stub
		System.out.println("how many seats u want to book : ");
		int bookSeat=sc.nextInt();
		int count=0,c=0;
		for(int i=0;i<seat.length;i++)
		{
			for(int j=0;j<seat[i].length;j++)
			{
				if(seat[i][j].getAvailbleSeat()==0)
				{
					seat[i][j].setAvailbleSeat(1);
					seat[i][j].setPrice(100);
					int unique=(int)Math.random()*100;
					seat[i][j].setUniqueReservationNo(unique);
					count++;
					//System.out.print(count+"--");
					if(count==bookSeat)
					{
						c=1;
						break;
					
					}
					
				}
			}
			if(c==1)
				break;
			//System.out.print(count+"--");
			
		}
		
		
	}
	private static void displaySeatingChart() {
		// TODO Auto-generated method stub
		for(int i=0;i<seat.length;i++)
		{
			for(int j=0;j<seat[i].length;j++)
			{
				if(seat[i][j].getAvailbleSeat()==1)
				{
					System.out.print("sold:   "+seat[i][j].getAvailbleSeat()+"-----");
				}
				else
				System.out.print("ava  "+seat[i][j].getAvailbleSeat()+"-----");
			}
		System.out.println();
		}
		System.out.println("=========================");
	}
}
