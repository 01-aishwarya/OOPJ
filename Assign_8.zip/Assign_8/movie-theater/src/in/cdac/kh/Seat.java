package in.cdac.kh;

public class Seat {
	private int totalSeat;
	private int availbleSeat;
	private int uniqueReservationNo;
	private double revenue;
	private double price;
	public Seat(int totalSeat, int availbleSeat, int uniqueReservationNo, double revenue, double price) {
		super();
		this.totalSeat = totalSeat;
		this.availbleSeat = availbleSeat;
		this.uniqueReservationNo = uniqueReservationNo;
		this.revenue = revenue;
		this.price = price;
	}
	public Seat() {
		super();
	}
	public int getTotalSeat() {
		return totalSeat;
	}
	public void setTotalSeat(int totalSeat) {
		this.totalSeat = totalSeat;
	}
	public int getAvailbleSeat() {
		return availbleSeat;
	}
	public void setAvailbleSeat(int availbleSeat) {
		this.availbleSeat = availbleSeat;
	}
	public int getUniqueReservationNo() {
		return uniqueReservationNo;
	}
	public void setUniqueReservationNo(int uniqueReservationNo) {
		this.uniqueReservationNo = uniqueReservationNo;
	}
	public double getRevenue() {
		return revenue;
	}
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	
	
}

