package in.cdac.kh;

import java.util.Scanner;

public class UserArray {
	public static Scanner sc=new Scanner(System.in);
	public static int[] arr;
	private static void print() {
		// TODO Auto-generated method stub
		  System.out.print("Array Elements Are :		");
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
		  System.out.println();
		
	}
	
	private static int sum() {
		int sum=0;
		for(int i:arr)
			sum=sum+i;
		return sum;
	}
	
	private static void avg() {
		// TODO Auto-generated method stub
		System.out.print("Average :		");
		int sum=UserArray.sum();
		int avg=sum/arr.length;
		System.out.print(avg+"\n");
		
	}
	private static void min() {
		// TODO Auto-generated method stub
		
		int min=arr[0];
		for(int i:arr)
			{
			if(min >i)
				min=i;
			}
		System.out.print("Min :		"+min+"\n");
		
	}

	private static void max() {
		// TODO Auto-generated method stub
		int max=arr[0];
		for(int i:arr)
			{
			if(max <i)
				max=i;
			}
		System.out.print("Max :		"+max+"\n");
		
	}
	
	private static void sort() {
		// TODO Auto-generated method stub
		for(int i=0;i<arr.length-1;i++)
		{
			for(int j=0;j<arr.length-1;j++)
			{
				if(arr[j] >arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		UserArray.print();
	}

	
	public static void main(String[] args)
	{
	  System.out.print("Enter array size :		");
	  arr=new int[sc.nextInt()];
      
	  for(int i=0;i<arr.length;i++)
		  arr[i]=sc.nextInt();
	  
	  UserArray.print();
	  System.out.print("Sum :		");
	  System.out.print(UserArray.sum()+"\n");
	  UserArray.avg();
	  UserArray.max();
	  UserArray.min();
	  UserArray.sort();
	}

	
	

	

	


	

}
