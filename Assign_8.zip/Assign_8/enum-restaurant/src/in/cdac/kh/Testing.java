package in.cdac.kh;

import java.util.Scanner;

public class Testing {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Dish dish;
		
		
		int choice=1;
		
		while(choice!=0)
		{
			System.out.println("enter dish number ");
			System.out.println("1 .POHE - 40 Rs ");
			System.out.println("2 .VADAPAV - 15 Rs ");
			System.out.println("3 .TEA - 10 Rs ");
			System.out.println("4 .KHICHDI- 80 Rs ");
			System.out.println("=================== ");
			
			choice=sc.nextInt();
			System.out.println("enter quantity ");
			int no=sc.nextInt();
			switch(choice)
			{
			case 1:
				dish=Dish.valueOf("POHE");
				dish.takeOrder(dish, no);
				break;
			case 2:
				dish=Dish.valueOf("VADAPAV");
				dish.takeOrder(dish, no);
				break;
			case 3:
				dish=Dish.valueOf("TEA");
				dish.takeOrder(dish, no);
				break;
			case 4:
				dish=Dish.valueOf("KHICHDI");
				dish.takeOrder(dish, no);
				break;
				
			}
			
			System.out.println("Would you like to place another order? (Y/N): Y ");
			char c=sc.next().charAt(0);
			if(c=='y' || c=='Y')
			{
				continue;
			}
			else
			{
				choice=0;
			}
		}
		
		
		
		
		
		
		

		
		
	}
}
