package in.cdac.kh;

public enum Dish {

	EXIT,POHE(40,"pohe"),VADAPAV(15,"vadapav"),TEA(10,"tea"),KHICHDI(80,"khichdi");
	
	private int price;
	private String name;
	Dish(int price,String name)
	{
		this.price=price;
		this.name=name;
	}
	Dish()
	{
		
	}
	public void printMenu()
	{
		Dish[] dish=Dish.values();
		for(Dish e:dish)
			System.out.println(e.name+" "+e.price);
	}
	
	public void takeOrder(Dish d,int no)
	{
		int pr=0;
		Dish[] dish=Dish.values();
		
		for(int i=0;i<dish.length;i++)
		{
			if(i==d.ordinal())
			{
				pr=dish[i].price*no;
				break;
			}
			//System.out.println(di.name+" "+e.price);
		}
		
		System.out.println(pr);
		System.out.println("=================== ");
		
	}
}
