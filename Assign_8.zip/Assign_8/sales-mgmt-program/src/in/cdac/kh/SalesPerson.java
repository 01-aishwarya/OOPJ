package in.cdac.kh;

public class SalesPerson {
	private int id;
	private String SalesPersonname;
	private int salesFigure;
	private int totalSales;
	public SalesPerson(int id, String salesPersonname, int salesFigure, int totalSales) {
		super();
		this.id = id;
		SalesPersonname = salesPersonname;
		this.salesFigure = salesFigure;
		this.totalSales = totalSales;
	}
	public SalesPerson() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSalesPersonname() {
		return SalesPersonname;
	}
	public void setSalesPersonname(String salesPersonname) {
		SalesPersonname = salesPersonname;
	}
	public int getSalesFigure() {
		return salesFigure;
	}
	public void setSalesFigure(int salesFigure) {
		this.salesFigure = salesFigure;
	}
	public int getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(int totalSales) {
		this.totalSales = totalSales;
	}
	
	
	

}
