package in.cdac.kh;

import java.util.Scanner;

public class SalesPersonTesting {
	public static Scanner sc=new Scanner(System.in);
	public static SalesPerson[] person;
	public static void main(String[] args)
	{
		person=new SalesPerson[10];
	
		
        int choice=1;
		
		while(choice!=0)
		{
			System.out.println("1. Add SalesPerson : ");
			System.out.println("2. View SalesPerson By Name: ");
			System.out.println("3. View All SalesPerson : ");
			System.out.println("4. Update Sales fig of SalesPerson By Id : ");
			System.out.println("5. Total Sales fig of SalesPerson By Id : ");
			System.out.println("6. All Sales of All SalesPerson  : ");
			System.out.println("0. To EXIT : ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				SalesPersonTesting.addSalesPerson();
				break;
			case 2:
				SalesPersonTesting.viewSalesPersonByName();
			    break;
			case 3:
				SalesPersonTesting.viewAllSalesPerson();
				break;
			case 4:
				SalesPersonTesting.updateSalesFigureById();
				break;
			case 5:
				SalesPersonTesting.totalSalesOfSalesPersonById();
				break;
			case 6:
				SalesPersonTesting.totalSalesOfAllSalesPerson();
				break;
			case 0:
				System.out.println("You're Exited...");
				System.out.println("=========================");
			}
		}
		
		
		
		
	}
	
	
	private static void totalSalesOfAllSalesPerson() {
		
		for(int i=0;i<person.length;i++)
			if(person[i]!=null )
				System.out.println("total sales : "+person[i].getTotalSales());
		
		System.out.println("=======================");
	}
	
	
	
	private static void totalSalesOfSalesPersonById() {
		// TODO Auto-generated method stub
		System.out.println("enter id : 	");
		int id=sc.nextInt();
		
		System.out.println("enter total no of exp : 	");
		int yr=sc.nextInt();
		int total=0;
		
		for(int i=0;i<person.length;i++)
		{
			if(person[i]!=null && person[i].getId()==id)
			{
				
				total=person[i].getSalesFigure()*yr;
			person[i].setTotalSales(total);
				System.out.println("total sales : "+total);
				System.out.println("=======================");
				
				break;
			}
		}
	}
	
	
	
	private static void updateSalesFigureById() {
		// TODO Auto-generated method stub
		System.out.println("enter id : 	");
		int id=sc.nextInt();
		System.out.println("enter sales fig to update : 	");
		int fig=sc.nextInt();
		
		for(int i=0;i<person.length;i++)
		{
			if(person[i]!=null && person[i].getId()==id)
			{
				person[i].setSalesFigure(fig);
				System.out.println("updated successfully !!!");
				System.out.println("=======================");
				
				break;
			}
		}
	}
	
	
	
	private static void viewAllSalesPerson() {
		
		for(int i=0;i<person.length;i++)
		{
			if(person[i]!=null )
			{
				System.out.println("id 			:	"+person[i].getId()+" ");
				System.out.println("name 			:	"+person[i].getSalesPersonname()+" ");
				System.out.println("sales fig 	:	"+person[i].getSalesFigure()+" ");
				System.out.println("total sales	:	"+person[i].getTotalSales()+" ");
				System.out.println("-----------------");
			}
			
			
		}
		System.out.println("=======================");
	}
	
	
	private static void viewSalesPersonByName() {
		// TODO Auto-generated method stub
		System.out.print("enter name : 	");
		String name=sc.next();
		
		for(int i=0;i<person.length;i++)
		{
			if(person!=null && person[i].getSalesPersonname().equals(name))
			{
				System.out.println("id 			:	"+person[i].getId()+" ");
				System.out.println("name 			:	"+person[i].getSalesPersonname()+" ");
				System.out.println("sales fig 	:	"+person[i].getSalesFigure()+" ");
				System.out.println("total sales	:	"+person[i].getTotalSales()+" ");
				break;
			}
		}
		System.out.println("=======================");
		
	}
	
	
	private static void addSalesPerson() {
		// TODO Auto-generated method stub
		System.out.print("enter name : 	");
		String name=sc.next();
		System.out.print("enter sales figure of last 12 months : 	");
		int fig=sc.nextInt();
		for(int i=0;i<person.length;i++)
		{
			if(person[i]==null)
			{
				person[i]=new SalesPerson(i,name,fig,0);
				System.out.println("added sucessfully!!!");
				break;
			}
		}
		
		System.out.println("=======================");
		
	}

}
