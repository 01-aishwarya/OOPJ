package in.cdac.kh;

public class FoodMenu {
	private String dish;
	private double price;
	public FoodMenu(String dish, double price) {
		super();
		this.dish = dish;
		this.price = price;
	}
	public FoodMenu() {
		super();
	}
	public String getDish() {
		return dish;
	}
	public void setDish(String dish) {
		this.dish = dish;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
