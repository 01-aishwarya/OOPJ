package in.cdac.kh;

import java.util.Scanner;

public class FoodMenuTesting {
	public static Scanner sc=new Scanner(System.in);
	public static FoodMenu[] menu;
	public static void main(String[] args)
	{
		menu=new FoodMenu[10];

		int choice=1;
		while(choice!=0)
		{
		System.out.println("1. View the current menu with prices");
		System.out.println("2. Add a new dish to the menu");
		System.out.println("3. Remove a dish from the menu");
		System.out.println("4. Modify the price of a dish on the menu");
		System.out.println("0. Exit the program");
		System.out.println("===========================");
		
				
		
		System.out.println("enter a choice :");
		choice=sc.nextInt();
		
		
			
			switch(choice)
			{
			case 1:
				FoodMenuTesting.display();
				break;
			case 2:
				FoodMenuTesting.addDish();
				break;
			case 3:
				FoodMenuTesting.remove();
				break;
			case 4:
				FoodMenuTesting.update();
				break;
				
			}
		}
		
	}
	
	private static void remove() {
		// TODO Auto-generated method stub
		
		System.out.println("enter dish  to remove");
		String s=sc.next();
	//	System.out.println("enter new price ");
		//double p=sc.nextDouble();
		for(int i=0;i<menu.length;i++) {
			
			if(menu[i]!=null && menu[i].getDish().equals(s))
			{
				menu[i]=null;
				break;
			}
		}
	}
	private static void update() {
		// TODO Auto-generated method stub
		
			System.out.println("enter dish to update");
			String s=sc.next();
			System.out.println("enter new price ");
			double p=sc.nextDouble();
			for(int i=0;i<menu.length;i++) {
				
				if(menu[i]!=null && menu[i].getDish().equals(s))
				{
					//System.out.println("enter ==============");
					menu[i].setPrice(p);
					break;
				}
				
			}
//	System.out.println("enter price to update");
		
		
	}
	private static void addDish() {
		// TODO Auto-generated method stub
		for(int i=0;i<menu.length;i++)
		{
			
			if(menu[i]==null)
			{
				System.out.print("enter a dish : ");
				String dish=sc.next();
				System.out.print("enter price of dish : ");
				double price=sc.nextDouble();
			menu[i]=new FoodMenu(dish,price);
			break;
			}
			
		}
		
	}
	private static void display() {
		for(int i=0;i<menu.length;i++)
		{
			if(menu[i]!=null)
			{
			System.out.println("Dish Name	:	"+menu[i].getDish());
			System.out.println("Dish Price	:	"+menu[i].getPrice());
			System.out.println("-----------------");
			}
			
				
		}
		
	}

}
