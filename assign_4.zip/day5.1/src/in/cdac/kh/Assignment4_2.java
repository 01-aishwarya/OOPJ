

//2)Write a Vehicle class with overloaded methods that have a different number of parameters.
//Demonstrate calling these overloaded methods with various numbers of arguments. 

package in.cdac.kh;


 class Vehicle
{
  private String company_name;
  private int color;
  private int model;
  
  void print(String name)
  {
	  System.out.println(name);
  }
 
  
  void print(int m,int c)
  {
	  System.out.println(m+" "+c);
  }
  
  
  void print(String name,int c,int m)
  {
	  System.out.println(m+" "+c+" "+name);
  }
 
 
}


public class Assignment4_2 {
	
	public static void main(String[] args)
	{
	 Vehicle v=new Vehicle();
	 v.print("Porsche");
	 v.print(109,4567);
	 v.print("Range Rover",3,5678);
	}

}
