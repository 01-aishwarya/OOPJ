
//) Build a class Student which contains details about the Student and compile and run its
//instance



package in.cdac.kh;

public class  Assignment4_1 {
	
	
		 public static void main(String[] args)
		 {
			
			 Student obj=new  Student();
			 obj.print();	 
		 }

}

class Student
{
	 private String name="aish";
		private int id=2;
		private String course="DAC";
		
		
		 void print()
		{
		System.out.println(name+" "+id+" "+course);
		}
	 
}


