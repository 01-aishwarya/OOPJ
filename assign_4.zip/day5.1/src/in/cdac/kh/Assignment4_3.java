

//  3)Create a class Employee with multiple overloaded methods that have different parameter types (e.g.,
// int, double, String). Demonstrate calling each overloaded method with appropriate arguments.



package in.cdac.kh;


class Employee
{
	 private String name;
	  private int id;
	  private double sal;
	  
	  void print(String name)
	  {
		  System.out.println(name);
	  }
	 
	  
	  void print(int id,double sal)
	  {
		  System.out.println(id+" "+sal);
	  }
	  
	  
	  void print(String name,int id,int sal)
	  {
		  System.out.println(name+" "+id+" "+sal);
	  }
}



public class Assignment4_3 {
	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.print("Sandeep");
		e.print(11,777);
		e.print("asih",4,555);
	}

}
